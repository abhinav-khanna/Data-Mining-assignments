README-Q2

Name: Abhinav Khanna
Entry No.: 2017csb1061

Procedure:

To generate dataset, ensure that the file generated_dataset.txt is empty. Then, run all the cells in the "Dataset generator.ipynb" sequentially. You can change the variables num_items and num_trans to change the number of items and number of transactions respectively. 

To run the algorithms on the generated dataset, run all the cell in the repsetive notebook. While running FP tree, please ensure that the file "Dataset generators_sorted.txt" is empty, as the file is written to in append mode. 