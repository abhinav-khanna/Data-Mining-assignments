README-Q1

Name: Abhinav Khanna
Entry No.: 2017csb1061

Procedure:

Since all the code is provided in Jupyter Notebook, you can easily run the code by running each cell sequentially. 
All notebooks are labeled in the format "<Algorithm>-<Dataset>.ipynb". 
Please ensure that the dataset files are in the same folder as the notebooks